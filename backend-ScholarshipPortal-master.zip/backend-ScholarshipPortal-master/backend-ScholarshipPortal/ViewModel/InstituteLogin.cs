﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend_ScholarshipPortal.ViewModel
{
    public class InstituteLogin
    {
        public int InstituteCode { get; set; }
        public string Password { get; set; }
    }
}
